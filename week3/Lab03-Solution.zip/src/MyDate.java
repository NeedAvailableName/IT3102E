import java.time.LocalDate;

import java.util.Scanner;  

public class MyDate {
	
	private int day = 1, month = 1, year = 1;
	
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public MyDate()
	{
		LocalDate today = LocalDate.now();
		
		setMonth(today.getMonthValue());
		setYear(today.getYear());
		setDay(today.getDayOfMonth());
	}
	
	public MyDate(int day, int month, int year)
	{
		this.setMonth(month);
		this.setYear(year);
		this.setDay(day);
	}
	
	public MyDate(String date)
	{
		String elemts[] = date.split(" ");
		
		this.year = Integer.parseInt(elemts[2]);
		if("January".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(1);
			
		}
		if("February".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(2);
		}
		if("March".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(3);
		}
		if("April".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(4);
		}
		if("May".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(5);
		}
		if("June".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(6);
		}
		if("July".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(7);
		}
		if("August".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(8);
		}
		if("September".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(9);
		}
		if("October".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(10);
		}
		if("November".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(11);
		}
		if("December".equalsIgnoreCase(elemts[0]))
		{
			this.setMonth(12);
		}
		
		this.setDay(Integer.parseInt(elemts[1].substring(0, elemts[1].length() - 2)));
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		if(month >= 1 && month <= 12)
			this.month = month;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		if(day >= 1 && day <= 31)
		{
			if(this.month == 4 || this.month == 6 || this.month == 9
					|| this.month == 11
					)
			{
				if(day <= 30)
					this.day = day;
			}
			if(this.month == 2)
			{
				if(this.year % 4 != 0)
				{
					if(day <= 28)
						this.day = day;
				}
				else {
					if(day <= 29)
						this.day = day;
				}
			}
		}
	}
	
	public void accept()
	{
		System.out.print("Type the date: ");
		Scanner myObj = new Scanner(System.in);  // Create a Scanner object
		
		String date = myObj.nextLine(); 
		date = date.trim();
		MyDate newDate = new MyDate(date);
		this.setDay(newDate.day);
		this.setMonth(newDate.month);
		this.setYear(newDate.year);
	}
	
	public void print()
	{
		System.out.println("The current date is: " 
					+ this.day + "/" + this.month + "/" + this.year);
	}
}
