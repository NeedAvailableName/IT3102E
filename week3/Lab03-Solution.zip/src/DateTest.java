import java.time.LocalDate;

public class DateTest {

	public static void main(String[] args) {
		
		//Keep in mind that you need set VM Argument to enable assert Junit test
		//You can read here: https://stackoverflow.com/questions/5509082/eclipse-enable-assertions
		//More specifically, look at: https://i.stack.imgur.com/x9TeH.png
		MyDate myDate1 = new MyDate();
		LocalDate today = LocalDate.now();
		
		//System.out.println(myDate1.getDay() + " " + today.getDayOfMonth());
		assert (myDate1.getDay() == today.getDayOfMonth()) : "Invalid Day"; 
		assert myDate1.getMonth() == today.getMonthValue() : "Invalid Month"; 
		assert (myDate1.getYear() == today.getYear()) : "Invalid Year"; 
		
		
		for(int y = 2010; y < 2014; y++)
		{
			for(int m = 1; m <= 12; m++)
			{
				for(int d = 1; d < 31; d++)
				{
					MyDate myDate2 = new MyDate(d, m, y);
					assertMyDate(myDate2);
				}
			}
		}
		
		String month[] = {"January", "February", "March", "April", "May",
							"June", "July", "August", "September", "October"
							, "November", "December"};
		String days[] = {"1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th",
							"9th", "10th", "11th", "12th", "13th", "14th", "15th",
							"16th", "17th", "18th", "19th", "20th", "21st",
							"22nd", "23rd", "24th", "25th", "26th", "27th",
							"28th", "29th", "30th", "31st"};
		
		
		
		for(int y = 2010; y < 2014; y++)
		{
			for(int m = 1; m <= 12; m++)
			{
				for(int d = 1; d < 31; d++)
				{
					String strMonth = month[m - 1];
					String strDay = days[d - 1];
					MyDate myDate3 = new MyDate(strMonth + " " + strDay + " " + y);
					assertMyDate(myDate3);
				}
			}
		}
		
		System.out.println("End of test");

	}
	
	public static void assertMyDate(MyDate myDate)
	{
		assert myDate.getYear() >= 0 : "Invalid Year"; 
		assert myDate.getDay() >= 1 || myDate.getDay() <= 31 : "Invalid Day";
		assert myDate.getMonth() > 0 || myDate.getMonth() <= 12 : "Invalid Month";
		
		if(myDate.getMonth() == 4 || myDate.getMonth() == 6 ||
				myDate.getMonth() == 9 || myDate.getMonth() == 11 
				)
		{
			assert myDate.getDay() <= 30 : "Invalid Day";
		}
		if(myDate.getMonth() == 2)
		{
			if(myDate.getYear() % 4 == 0)
			{
				assert myDate.getDay() <= 29 : "Invalid Day";
			}
			else {
				assert myDate.getDay() <= 28 : "Invalid Day";
			}
		}
	}

}
